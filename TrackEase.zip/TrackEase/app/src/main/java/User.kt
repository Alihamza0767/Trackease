data class User(
    val usertype : String? = null,
    val Username : String? = null,
    val email : String? = null,
    val pass : String? = null
)