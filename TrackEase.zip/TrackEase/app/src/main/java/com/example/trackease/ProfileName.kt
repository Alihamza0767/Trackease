package com.example.trackease


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ProfileName : AppCompatActivity() {

    private lateinit var databaseReference: DatabaseReference
    private lateinit var databaseReference2: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_name)

        val email = intent.getStringExtra("email")?.replace(",", ".") // Replace commas with dots
        val etName = findViewById<EditText>(R.id.name1)
        val editButton = findViewById<Button>(R.id.edit) // Reference to the edit button

        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("User")
        databaseReference2 = FirebaseDatabase.getInstance().getReference("Admin")

        // Retrieve the user with the specified email
        val query = databaseReference.orderByChild("email").equalTo(email)
        val query2 = databaseReference2.orderByChild("email").equalTo(email)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                Log.d("ProfileName", "DataSnapshot exists: ${dataSnapshot.exists()}")
                if (dataSnapshot.exists()) {
                    val user = dataSnapshot.children.first() // Get the first user with the specified email
                    val userId = user.key // Get the user ID

                    // Set OnClickListener on the edit button
                    editButton.setOnClickListener {
                        // Get the new username from the EditText
                        val newUsername = etName.text.toString()

                        // Update the username in the database
                        userId?.let {
                            databaseReference.child(it).child("username").setValue(newUsername)
                                .addOnSuccessListener {
                                    Toast.makeText(
                                        applicationContext,
                                        "Username updated successfully",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    // Navigate back to the Profile activity
                                    val intent = Intent(this@ProfileName, Profile::class.java)
                                    intent.putExtra("email",email)
                                    startActivity(intent)
                                    finish() // Finish the current activity
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(
                                        applicationContext,
                                        "Failed to update username: ${e.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                        }
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
                Toast.makeText(
                    applicationContext,
                    "Database error: ${databaseError.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })


        query2.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                Log.d("ProfileName", "DataSnapshot exists: ${dataSnapshot.exists()}")
                if (dataSnapshot.exists()) {
                    val user = dataSnapshot.children.first() // Get the first user with the specified email
                    val userId = user.key // Get the user ID

                    // Set OnClickListener on the edit button
                    editButton.setOnClickListener {
                        // Get the new username from the EditText
                        val newUsername = etName.text.toString()

                        // Update the username in the database
                        userId?.let {
                            databaseReference2.child(it).child("username").setValue(newUsername)
                                .addOnSuccessListener {
                                    Toast.makeText(
                                        applicationContext,
                                        "Username updated successfully",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    // Navigate back to the Profile activity
                                    val intent = Intent(this@ProfileName, Profile::class.java)
                                    intent.putExtra("email",email)
                                    startActivity(intent)
                                    finish() // Finish the current activity
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(
                                        applicationContext,
                                        "Failed to update username: ${e.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                        }
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
                Toast.makeText(
                    applicationContext,
                    "Database error: ${databaseError.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
