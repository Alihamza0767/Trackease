package com.example.trackease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class catagory1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_catagory1)
    }
}