package com.example.trackease

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class intro : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)

        val button = findViewById<Button>(R.id.b1)
        button.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, intro2::class.java)
            startActivity(intent)
        }


        val button1 = findViewById<TextView>(R.id.skip)
        button1.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, intro4::class.java)
            startActivity(intent)
        }
    }
}