package com.mohammadhaadi.smd_project

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter_NotCompleted_Guest(private val items: List<Task_NotCompleted>) :
    RecyclerView.Adapter<Adapter_NotCompleted_Guest.ItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_guest_view, parent, false)
        return ItemViewHolder(view)
    }


    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int {
        return items.size
    }

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewItem: TextView = itemView.findViewById(R.id.title)
        private val textViewDescription: TextView = itemView.findViewById(R.id.time)

        fun bind(item: Task_NotCompleted) {
            textViewItem.text = item.title
            textViewDescription.text = item.description
        }
    }
}