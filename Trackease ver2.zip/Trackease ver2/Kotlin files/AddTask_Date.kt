package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AddTask_Date : AppCompatActivity() {

    private var selectedYear: String = ""
    private var selectedMonth: String = ""
    private var selectedDayOfMonth: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task_date)

        val email = intent.getStringExtra("email")

        Toast.makeText(this, email, Toast.LENGTH_LONG).show()


        val calendarView = findViewById<CalendarView>(R.id.date)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->

            selectedYear = year.toString()
            selectedMonth = (month + 1).toString()
            selectedDayOfMonth = dayOfMonth.toString()

            Toast.makeText(this, selectedDayOfMonth, Toast.LENGTH_SHORT).show()
        }




        val secondActbutton = findViewById<Button>(R.id.time)
        secondActbutton.setOnClickListener{
            val intent = Intent(this, AddTask_time::class.java).apply {
                putExtra("email", email)
                putExtra("day", selectedDayOfMonth)
                putExtra("month", selectedMonth)
                putExtra("year", selectedYear)
            }
            startActivity(intent)
        }



    }
}