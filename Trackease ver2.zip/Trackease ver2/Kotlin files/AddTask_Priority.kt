package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.RelativeLayout

class AddTask_Priority : AppCompatActivity() {

    lateinit var priority1: RelativeLayout
    lateinit var priority2: RelativeLayout
    lateinit var priority3: RelativeLayout
    var p: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task_priority)

        val email = intent.getStringExtra("email")
        val hour = intent.getStringExtra("hour")
        val minute = intent.getStringExtra("minute")
        val type = intent.getStringExtra("type")
        val day = intent.getStringExtra("day")
        val cat = intent.getStringExtra("cat")


        priority1 = findViewById(R.id.priority1)
        priority2 = findViewById(R.id.priority2)
        priority3 = findViewById(R.id.priority3)


        priority1.setOnClickListener {
            updatePriority(it as RelativeLayout, 1)
        }
        priority2.setOnClickListener {
            updatePriority(it as RelativeLayout, 2)
        }
        priority3.setOnClickListener {
            updatePriority(it as RelativeLayout, 3)
        }



        val secondActbutton = findViewById<Button>(R.id.save)
        secondActbutton.setOnClickListener{
            val intent = Intent(this, AddTask::class.java).apply {
                putExtra("email", email)
                putExtra("hour", hour)
                putExtra("minute", minute)
                putExtra("type", type)
                putExtra("day", day)
                putExtra("cat", cat)
                putExtra("priority", p.toString())
            }
            startActivity(intent)
        }


    }


    private fun updatePriority(clickedView: RelativeLayout, value: Int) {
        // Reset backgrounds for all priority layouts
        priority1.setBackgroundResource(R.drawable.black_rounded)
        priority2.setBackgroundResource(R.drawable.black_rounded)
        priority3.setBackgroundResource(R.drawable.black_rounded)

        // Set the clicked priority layout background to purple
        clickedView.setBackgroundResource(R.drawable.purple_rounded)

        // Update the value of variable p
        p = value
    }


}