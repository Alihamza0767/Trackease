package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class AddTask_guest : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task_guest)

        val name = intent.getStringExtra("name")

        val editText1 = findViewById<EditText>(R.id.title)
        val editText2 = findViewById<EditText>(R.id.desc)


        val fourthActbutton = findViewById<ImageView>(R.id.submit)
        fourthActbutton.setOnClickListener{

            val text1 = editText1.text.toString()
            val text2 = editText2.text.toString()

            if (name != null) {
                sendDataToServer(text1,text2,name,"not")
            }
        }


    }


    private fun sendDataToServer(title: String, description: String,email: String,status: String) {
        val url = "http://192.168.32.1/SMD_Project/insert_task.php"
        val requestQueue = Volley.newRequestQueue(this)

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                Toast.makeText(this, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("response", it.toString())
                // If you expect a JSON object in the response, handle it here
                try {
                    val res = JSONObject(it)
                    val success = res.getInt("status")
                    val message = res.getString("message")
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    if (success == 1) {
                        // Data inserted successfully
                        // Handle your logic here
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(this, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("error", it.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["title"] = title
                params["description"] = description
                params["hour"] = ""
                params["minute"] = ""
                params["type"] = ""
                params["day"] = ""
                params["priority"] = ""
                params["category"] = ""
                params["email"] = email
                params["status"] = status
                return params
            }
        }
        requestQueue.add(stringRequest)
    }

}