package com.mohammadhaadi.smd_project

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.mohammadhaadi.smd_project.databinding.ActivityAddTaskTimeBinding
import java.util.Calendar
import java.util.Date

class AddTask_time : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskTimeBinding
    private var day: String? = null
    private var month: String? = null
    private var year: String? = null
    private var time_hour: String? = null
    private var time_minute: String? = null

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskTimeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val email = intent.getStringExtra("email")
        day = intent.getStringExtra("day")
        month = intent.getStringExtra("month")
        year = intent.getStringExtra("year")

        createNotificationChannel()


        Toast.makeText(this, month , Toast.LENGTH_LONG).show()


        val editText1 = findViewById<EditText>(R.id.time_hour)
        val editText2 = findViewById<EditText>(R.id.time_minute)
        val editText3 = findViewById<EditText>(R.id.time_type)



        //time_hour = editText1.text.toString()
        //time_minute = editText2.text.toString()
        val time_type = editText3.text.toString()



        val secondActbutton = findViewById<Button>(R.id.save)
        secondActbutton.setOnClickListener{

            time_hour = editText1.text.toString()
            time_minute = editText2.text.toString()

            scheduleNotification()

            val intent = Intent(this, AddTask::class.java).apply {
                putExtra("email", email)
                putExtra("hour", time_hour)
                putExtra("minute", time_minute)
                putExtra("type", time_type)
                putExtra("day", day)
            }
            startActivity(intent)
        }

    }

   @SuppressLint("ScheduleExactAlarm")
    private fun scheduleNotification() {
        val intent = Intent(applicationContext, Notification::class.java)
        val title = "TrackEase"
        val message = "Your Task is due at    "+time_hour+" : "+time_minute
        intent.putExtra(titleExtra, title)
        intent.putExtra(messageExtra, message)

        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext,
            notificationID,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val time = getTime()
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            time,
            pendingIntent
        )
        showAlert(time, title, message)
    }

    private fun showAlert(time: Long, title: String, message: String) {
        val date = Date(time)
        val dateFormat = android.text.format.DateFormat.getLongDateFormat(applicationContext)
        val timeFormat = android.text.format.DateFormat.getTimeFormat(applicationContext)

        AlertDialog.Builder(this)
            .setTitle("Notification Scheduled")
            .setMessage(
                "Title: " + title +
                        "\nMessage: " + message +
                        "\nAt: " + dateFormat.format(date) + " " + timeFormat.format(date)
            )
            .setPositiveButton("Okay") { _, _ -> }
            .show()
    }

    private fun getTime(): Long {
        val minute = time_minute?.toInt()
        val hour = time_hour?.toInt()
        val day1 = day?.toInt()
        val month1 = month?.toInt()
        val year1 = year?.toInt()

        val calendar = Calendar.getInstance()

        if (year1 != null) {
            if (month1 != null) {
                if (day1 != null) {
                    if (hour != null) {
                        if (minute != null) {
                            calendar.set(year1, month1-1, day1, hour, minute)
                            return calendar.timeInMillis
                        }
                    }
                }
            }
        }
        return calendar.timeInMillis
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel() {
        val name = "Notif Channel"
        val desc = "A Description of the Channel"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelID, name, importance)
        channel.description = desc
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

}