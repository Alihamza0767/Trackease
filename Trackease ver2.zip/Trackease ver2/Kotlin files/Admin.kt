package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class Admin : AppCompatActivity() {

    private lateinit var taskRecyclerView: RecyclerView
    private lateinit var tasksList: MutableList<Task_Completed>
    private lateinit var taskAdapter: TaskAdapter_Completed

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        taskRecyclerView = findViewById(R.id.recyclerView)

        tasksList = mutableListOf()
        taskAdapter = TaskAdapter_Completed(tasksList)
        taskRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@Admin, LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter
        }

        val thirdActbutton = findViewById<ImageView>(R.id.review)
        thirdActbutton.setOnClickListener{

            val intent = Intent(this,Review_User_Guest::class.java)
            startActivity(intent)

        }

        fetchData()


    }

    private fun fetchData() {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_all.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_Completed(name,decription,hour,minute,type, email, country, phno)
                            tasksList.add(user)
                        }
                        taskAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                return HashMap()
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }

}