package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CalendarView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class CalenderView2_Completed : AppCompatActivity() {

    private lateinit var tasksList: MutableList<Task_Completed>
    private lateinit var taskAdapter: TaskAdapter_Completed
    private lateinit var selectedDate: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calender_view2_completed)


        val recyclerView2: RecyclerView = findViewById(R.id.recyclerView2)


        tasksList = mutableListOf()
        taskAdapter = TaskAdapter_Completed(tasksList)
        recyclerView2.apply {
            layoutManager = LinearLayoutManager(this@CalenderView2_Completed, LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter
        }

        taskAdapter.setOnItemClickListener { item: Task_Completed ->

            val intent = Intent(this, EditTask::class.java)
            intent.putExtra("title", item.title)
            intent.putExtra("desc", item.description)
            intent.putExtra("hour", item.hour)
            intent.putExtra("minute", item.minute)
            intent.putExtra("type", item.type)
            intent.putExtra("category", item.category)
            intent.putExtra("priority", item.priority)
            startActivity(intent)
        }

        val calendarView = findViewById<CalendarView>(R.id.calenderView)

        calendarView.setOnDateChangeListener { view, year, month, dayOfMonth ->
            // Month is 0 based, so add 1 to month
            val formattedMonth = if (month < 9) "0${month + 1}" else "${month + 1}"
            val formattedDayOfMonth = if (dayOfMonth < 10) "0$dayOfMonth" else "$dayOfMonth"

            selectedDate = "$formattedDayOfMonth"
            Toast.makeText(this, selectedDate, Toast.LENGTH_SHORT).show()

            fetchData_Date(selectedDate)


        }
    }



    private fun fetchData_Date(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_date.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_Completed(name, decription , hour,minute,type, email, country, phno)
                            tasksList.add(user)
                        }
                        taskAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["day"] = email
                return params
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }




}