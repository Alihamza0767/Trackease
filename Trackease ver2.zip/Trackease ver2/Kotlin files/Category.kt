package com.mohammadhaadi.smd_project

data class Category(var category: String = "",
                    var email: String = "",)
