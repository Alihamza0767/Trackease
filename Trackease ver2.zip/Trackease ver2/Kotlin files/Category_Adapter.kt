package com.mohammadhaadi.smd_project

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Category_Adapter(private val items: List<Category>) :
    RecyclerView.Adapter<Category_Adapter.ItemViewHolder>() {

    // Define a listener interface
    interface OnItemClickListener {
        fun onItemClick(item: Category)
    }

    private var listener: OnItemClickListener? = null

    fun setOnItemClickListener(listener: (Category) -> Unit) {
        this.listener = object : OnItemClickListener {
            override fun onItemClick(item: Category) {
                listener(item)
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_category_row, parent, false)
        return ItemViewHolder(view)
    }


    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewItem: TextView = itemView.findViewById(R.id.category)

        init {
            // Set click listener to the title TextView
            textViewItem.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener?.onItemClick(items[position])
                }
            }
        }

        fun bind(item: Category) {
            textViewItem.text = item.category
        }
    }
}

