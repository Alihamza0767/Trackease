package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class Choose_Category : AppCompatActivity() {

    private lateinit var categoryRecyclerView: RecyclerView
    private lateinit var categoryList: MutableList<Category>
    private lateinit var categoryAdapter: Category_Adapter
    private var selectedCat: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_category)

        val email = intent.getStringExtra("email")
        val hour = intent.getStringExtra("hour")
        val minute = intent.getStringExtra("minute")
        val type = intent.getStringExtra("type")
        val day = intent.getStringExtra("day")

        Toast.makeText(this, email, Toast.LENGTH_LONG).show()


        val imageView: ImageView = findViewById(R.id.c1)
        val imageView2: ImageView = findViewById(R.id.c2)
        val imageView3: ImageView = findViewById(R.id.c3)
        val imageView4: ImageView = findViewById(R.id.c4)


        imageView.setOnClickListener {
            selectedCat = "Grocery"
        }
        imageView2.setOnClickListener {
            selectedCat = "Home"
        }
        imageView3.setOnClickListener {
            selectedCat = "Sports"
        }
        imageView4.setOnClickListener {
            selectedCat = "Work"
        }


        val hActbutton = findViewById<Button>(R.id.addcat)
        hActbutton.setOnClickListener{
            val intent = Intent(this, AddTask::class.java).apply {
                putExtra("email", email)
                putExtra("hour", hour)
                putExtra("minute", minute)
                putExtra("type", type)
                putExtra("day", day)
                putExtra("cat", selectedCat)
            }
            startActivity(intent)
        }


        categoryList = mutableListOf()

        categoryRecyclerView = findViewById(R.id.category_recycler)
        categoryRecyclerView.layoutManager = LinearLayoutManager(this)
        categoryAdapter = Category_Adapter(categoryList)
        categoryRecyclerView.adapter = categoryAdapter


        categoryAdapter = Category_Adapter(categoryList)
        categoryRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@Choose_Category, LinearLayoutManager.HORIZONTAL, false)
            adapter = categoryAdapter
        }


        // Set item click listener on the adapter
        categoryAdapter.setOnItemClickListener { item: Category ->
            val intent = Intent(this, AddTask::class.java)
            intent.putExtra("email", email)
            intent.putExtra("hour", hour)
            intent.putExtra("minute", minute)
            intent.putExtra("type", type)
            intent.putExtra("day", day)
            intent.putExtra("cat", item.category)
            startActivity(intent)
        }

        val secondActbutton = findViewById<ImageView>(R.id.newc)
        secondActbutton.setOnClickListener{

            val intent = Intent(this,New_Category::class.java)
            startActivity(intent)

        }

        fetchData(email.toString())


    }





    private fun fetchData(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_review.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val category = obj.getString("category")
                            val email = obj.getString("email")
                            val user = Category(category, email)
                            categoryList.add(user)
                        }
                        categoryAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }

}