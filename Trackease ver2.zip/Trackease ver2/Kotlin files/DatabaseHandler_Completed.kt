package com.mohammadhaadi.smd_project

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

val DATABASE_NAME ="MyDB"
val TABLE_NAME="tasks"
val COL_ID = "id"
val COL_title = "title"
val COL_desc = "desc"
val COL_hour = "hour"
val COL_minute = "minute"
val COL_type = "type"
val COL_day = "day"
val COL_priority = "priority"

class DataBaseHandler(var context: Context) : SQLiteOpenHelper(context,DATABASE_NAME,null,1){
    override fun onCreate(db: SQLiteDatabase?) {

        val createTable = "CREATE TABLE " + TABLE_NAME +" (" +
                COL_ID +" INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_title + " VARCHAR(256)," +
                COL_desc +" VARCHAR(256)," + // Removed extra ")"
                COL_hour +" VARCHAR(256)," + // Removed extra ")"
                COL_minute +" VARCHAR(256)," + // Removed extra ")"
                COL_type +" VARCHAR(256)," + // Removed extra ")"
                COL_day +" VARCHAR(256)," + // Removed extra ")"
                COL_priority +" VARCHAR(256))" // Removed extra ")"

        db?.execSQL(createTable)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    fun insertData(tasks : Task_Completed){
        val db = this.writableDatabase
        var cv = ContentValues()
        cv.put(COL_title,tasks.title)
        cv.put(COL_desc,tasks.description)
        cv.put(COL_hour,tasks.hour)
        cv.put(COL_minute,tasks.minute)
        cv.put(COL_type,tasks.type)
        cv.put(COL_day,tasks.day)
        cv.put(COL_priority,tasks.priority)
        var result = db.insert(TABLE_NAME,null,cv)
        if(result == -1.toLong())
            Toast.makeText(context,"Failed", Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(context,"Success int SQLite", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("Range")
    fun readData() : MutableList<Task_Completed>{
        var list : MutableList<Task_Completed> = ArrayList()

        val db = this.readableDatabase
        val query = "Select * from " + TABLE_NAME
        val result = db.rawQuery(query,null)
        if(result.moveToFirst()){
            do {
                var user = Task_Completed()
                user.title = result.getString(result.getColumnIndex(COL_title))
                user.description = result.getString(result.getColumnIndex(COL_desc))
                user.hour = result.getString(result.getColumnIndex(COL_hour))
                user.minute = result.getString(result.getColumnIndex(COL_minute))
                user.type = result.getString(result.getColumnIndex(COL_type))
                user.day = result.getString(result.getColumnIndex(COL_day))
                user.priority = result.getString(result.getColumnIndex(COL_priority))
                list.add(user)
            }while (result.moveToNext())
        }

        result.close()
        db.close()
        return list
    }

}