package com.mohammadhaadi.smd_project

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

val DATABASE_NAME2 ="MyDB2"
val TABLE_NAME2="tasks"
val COL_ID2 = "id"
val COL_title2 = "title"
val COL_desc2 = "desc"
val COL_hour2 = "hour"
val COL_minute2 = "minute"
val COL_type2 = "type"
val COL_day2 = "day"
val COL_priority2 = "priority"

class DataBaseHandler2(var context: Context) : SQLiteOpenHelper(context,DATABASE_NAME2,null,1){
    override fun onCreate(db: SQLiteDatabase?) {

        val createTable = "CREATE TABLE " + TABLE_NAME2 +" (" +
                COL_ID2 +" INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_title2 + " VARCHAR(256)," +
                COL_desc2 +" VARCHAR(256)," + // Removed extra ")"
                COL_hour2 +" VARCHAR(256)," + // Removed extra ")"
                COL_minute2 +" VARCHAR(256)," + // Removed extra ")"
                COL_type2 +" VARCHAR(256)," + // Removed extra ")"
                COL_day2 +" VARCHAR(256)," + // Removed extra ")"
                COL_priority2 +" VARCHAR(256))" // Removed extra ")"

        db?.execSQL(createTable)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    fun insertData(tasks : Task_NotCompleted){
        val db = this.writableDatabase
        var cv = ContentValues()
        cv.put(COL_title2,tasks.title)
        cv.put(COL_desc2,tasks.description)
        cv.put(COL_hour2,tasks.hour)
        cv.put(COL_minute2,tasks.minute)
        cv.put(COL_type2,tasks.type)
        cv.put(COL_day2,tasks.day)
        cv.put(COL_priority2,tasks.priority)
        var result = db.insert(TABLE_NAME2,null,cv)
        if(result == -1.toLong())
            Toast.makeText(context,"Failed", Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(context,"Success int SQLite", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("Range")
    fun readData() : MutableList<Task_NotCompleted>{
        var list : MutableList<Task_NotCompleted> = ArrayList()

        val db = this.readableDatabase
        val query = "Select * from " + TABLE_NAME2
        val result = db.rawQuery(query,null)
        if(result.moveToFirst()){
            do {
                var user = Task_NotCompleted()
                user.title = result.getString(result.getColumnIndex(COL_title2))
                user.description = result.getString(result.getColumnIndex(COL_desc2))
                user.hour = result.getString(result.getColumnIndex(COL_hour2))
                user.minute = result.getString(result.getColumnIndex(COL_minute2))
                user.type = result.getString(result.getColumnIndex(COL_type2))
                user.day = result.getString(result.getColumnIndex(COL_day2))
                user.priority = result.getString(result.getColumnIndex(COL_priority2))
                list.add(user)
            }while (result.moveToNext())
        }

        result.close()
        db.close()
        return list
    }

}