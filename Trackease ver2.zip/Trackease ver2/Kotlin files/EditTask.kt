package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class EditTask : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task)

        val title = intent.getStringExtra("title")
        val desc = intent.getStringExtra("desc")
        val hour = intent.getStringExtra("hour")
        val minute = intent.getStringExtra("minute")
        val type = intent.getStringExtra("type")
        val category = intent.getStringExtra("category")
        val priority = intent.getStringExtra("priority")

        val context = this
        var db = DataBaseHandler2(context)


        val textView = findViewById<TextView>(R.id.title)
        textView.text = title

        val textView2 = findViewById<TextView>(R.id.desc)
        textView2.text = desc

        val textView3 = findViewById<TextView>(R.id.category)
        textView3.text = category


        val textView4 = findViewById<TextView>(R.id.priority)
        textView4.text = priority


        val textView5 = findViewById<TextView>(R.id.hour)
        textView5.text = hour

        val textView6 = findViewById<TextView>(R.id.minute)
        textView6.text = minute

        val secondActbutton = findViewById<TextView>(R.id.delete)
        secondActbutton.setOnClickListener{

            val intent = Intent(this,EditTask_Delete::class.java)
            startActivity(intent)

        }

        val thirdActbutton = findViewById<TextView>(R.id.delete)
        thirdActbutton.setOnClickListener{
            val intent = Intent(this, EditTask_Delete::class.java).apply {
                putExtra("title", title)
            }
            startActivity(intent)
        }

        val fifthActbutton = findViewById<Button>(R.id.edit)
        fifthActbutton.setOnClickListener{

            val intent = Intent(this,EditTask_Title::class.java)
            startActivity(intent)

        }


        val fourthActbutton = findViewById<Button>(R.id.markDone)
        fourthActbutton.setOnClickListener{
            markDone(title.toString())
            val notCompleted = Task_NotCompleted(title.toString(),desc.toString(),hour.toString(),minute.toString(),type.toString(),category.toString(),priority.toString())
            db.insertData(notCompleted)
        }

    }






    private fun markDone(title: String) {
        val url = "http://192.168.32.1/SMD_Project/mark_as_done.php" // Replace this with your server URL

        val requestQueue = Volley.newRequestQueue(this)
        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    // Parse the response JSON object
                    val jsonResponse = JSONObject(response)
                    val status = jsonResponse.getInt("status")
                    val message = jsonResponse.getString("message")

                    if (status == 1) {
                        // Message deleted successfully
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    } else {
                        // Message deletion failed
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    // Notify user of error
                    Toast.makeText(this, "Error deleting message", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Notify user of error
                Toast.makeText(this, "Error deleting message: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["title"] = title
                return params
            }
        }

        requestQueue.add(stringRequest)
    }



}