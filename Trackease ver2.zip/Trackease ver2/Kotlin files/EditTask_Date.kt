package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.Toast

class EditTask_Date : AppCompatActivity() {

    private var selectedYear: String = ""
    private var selectedMonth: String = ""
    private var selectedDayOfMonth: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task_date)

        val title = intent.getStringExtra("title")
        val desc = intent.getStringExtra("desc")

        Toast.makeText(this, title, Toast.LENGTH_LONG).show()



        val calendarView = findViewById<CalendarView>(R.id.date)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->

            selectedYear = year.toString()
            selectedMonth = (month + 1).toString()
            selectedDayOfMonth = dayOfMonth.toString()

            Toast.makeText(this, selectedDayOfMonth, Toast.LENGTH_SHORT).show()
        }



        val secondActbutton = findViewById<Button>(R.id.edit)
        secondActbutton.setOnClickListener{
            val intent = Intent(this, EditTask_time::class.java).apply {
                putExtra("day", selectedDayOfMonth)
                putExtra("title", title)
                putExtra("desc", desc)
            }
            startActivity(intent)
        }



    }
}