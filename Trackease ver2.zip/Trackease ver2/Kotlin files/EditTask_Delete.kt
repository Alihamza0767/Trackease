package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class EditTask_Delete : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task_delete)

        val title = intent.getStringExtra("title")

        Toast.makeText(this, title, Toast.LENGTH_SHORT).show()

        val secondActbutton = findViewById<TextView>(R.id.delete)
        secondActbutton.setOnClickListener{

            deleteTaskFromMySQL(title.toString())

        }

    }








    private fun deleteTaskFromMySQL(title: String) {
        val url = "http://192.168.32.1/SMD_Project/delete_task.php" // Replace this with your server URL

        val requestQueue = Volley.newRequestQueue(this)
        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    // Parse the response JSON object
                    val jsonResponse = JSONObject(response)
                    val status = jsonResponse.getInt("status")
                    val message = jsonResponse.getString("message")

                    if (status == 1) {
                        // Message deleted successfully
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    } else {
                        // Message deletion failed
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    // Notify user of error
                    Toast.makeText(this, "Error deleting message", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Notify user of error
                Toast.makeText(this, "Error deleting message: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["title"] = title
                return params
            }
        }

        // Add the request to the RequestQueue
        requestQueue.add(stringRequest)
    }






}