package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.util.HashMap

class EditTask_Priority : AppCompatActivity() {

    lateinit var priority1: RelativeLayout
    lateinit var priority2: RelativeLayout
    lateinit var priority3: RelativeLayout
    var p: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task_priority)

        val hour = intent.getStringExtra("hour")
        val minute = intent.getStringExtra("minute")
        val type = intent.getStringExtra("type")
        val day = intent.getStringExtra("day")
        val title = intent.getStringExtra("title")
        val desc = intent.getStringExtra("desc")

        val priority = "2"

        Toast.makeText(this, title, Toast.LENGTH_LONG).show()



        priority1 = findViewById(R.id.priority1)
        priority2 = findViewById(R.id.priority2)
        priority3 = findViewById(R.id.priority3)


        priority1.setOnClickListener {
            updatePriority(it as RelativeLayout, 1)
        }
        priority2.setOnClickListener {
            updatePriority(it as RelativeLayout, 2)
        }
        priority3.setOnClickListener {
            updatePriority(it as RelativeLayout, 3)
        }




        val fifthActbutton = findViewById<Button>(R.id.edit)
        fifthActbutton.setOnClickListener{
            updateTaskDataToDatabase(title.toString(),desc.toString(),hour.toString(),minute.toString(),type.toString(),day.toString(),p.toString())
        }





    }




    private fun updatePriority(clickedView: RelativeLayout, value: Int) {
        // Reset backgrounds for all priority layouts
        priority1.setBackgroundResource(R.drawable.black_rounded)
        priority2.setBackgroundResource(R.drawable.black_rounded)
        priority3.setBackgroundResource(R.drawable.black_rounded)

        // Set the clicked priority layout background to purple
        clickedView.setBackgroundResource(R.drawable.purple_rounded)

        // Update the value of variable p
        p = value
    }




    private fun updateTaskDataToDatabase(title: String, desc: String, hour: String, minute: String, type: String,day: String,priority: String) {
        val url = "http://192.168.32.1/SMD_Project/update_task.php"
        val requestQueue = Volley.newRequestQueue(this)

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                Toast.makeText(this, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("response", it.toString())
                // If you expect a JSON object in the response, handle it here
                try {
                    val res = JSONObject(it)
                    val success = res.getInt("status")
                    val message = res.getString("message")
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    if (success == 1) {
                        // Data updated successfully
                        // Handle your logic here
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(this, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("error", it.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["title"] = title
                params["description"] = desc
                params["hour"] = hour
                params["minute"] = minute
                params["type"] = type
                params["day"] = day
                params["priority"] = priority
                return params
            }
        }
        requestQueue.add(stringRequest)
    }




}