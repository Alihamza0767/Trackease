package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class EditTask_Title : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task_title)

        val editText1 = findViewById<EditText>(R.id.title)
        val editText2 = findViewById<EditText>(R.id.desc)



        val thirdActbutton = findViewById<TextView>(R.id.edit)
        thirdActbutton.setOnClickListener{

            val text1 = editText1.text.toString()
            val text2 = editText2.text.toString()

            val intent = Intent(this, EditTask_Date::class.java).apply {
                putExtra("title", text1)
                putExtra("desc", text2)
            }
            startActivity(intent)
        }


    }
}