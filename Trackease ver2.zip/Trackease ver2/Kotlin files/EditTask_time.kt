package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class EditTask_time : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task_time)

        val day = intent.getStringExtra("day")
        val title = intent.getStringExtra("title")
        val desc = intent.getStringExtra("desc")


        val editText1 = findViewById<EditText>(R.id.time_hour)
        val editText2 = findViewById<EditText>(R.id.time_minute)
        val editText3 = findViewById<EditText>(R.id.time_type)


        val secondActbutton = findViewById<Button>(R.id.edit)
        secondActbutton.setOnClickListener{

            val time_hour = editText1.text.toString()
            val time_minute = editText2.text.toString()
            val time_type = editText3.text.toString()

            val intent = Intent(this, EditTask_Priority::class.java).apply {
                putExtra("hour", time_hour)
                putExtra("minute", time_minute)
                putExtra("type", time_type)
                putExtra("day", day)
                putExtra("title", title)
                putExtra("desc", desc)
            }
            startActivity(intent)
        }

    }
}