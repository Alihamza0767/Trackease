package com.mohammadhaadi.smd_project

data class Focus(var id: String = "" , var time: String = "",
                 var email: String = "")
