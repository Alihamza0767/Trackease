package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONException
import org.json.JSONObject

class Guest : AppCompatActivity() {


    private lateinit var taskRecyclerView: RecyclerView
    private lateinit var tasksList: MutableList<Task_Completed>
    private lateinit var taskAdapter: Adapter_Completed_Guest
    private lateinit var taskRecyclerView2: RecyclerView
    private lateinit var tasksList2: MutableList<Task_NotCompleted>
    private lateinit var taskAdapter2: Adapter_NotCompleted_Guest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guest)

        val name = intent.getStringExtra("name")

        taskRecyclerView = findViewById(R.id.recyclerView)
        taskRecyclerView2 = findViewById(R.id.recyclerView2)

        tasksList = mutableListOf()
        taskAdapter = Adapter_Completed_Guest(tasksList)
        taskRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@Guest, LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter
        }


        taskAdapter.setOnItemClickListener { item: Task_Completed ->
            val intent = Intent(this, EditTask_Guest::class.java)
            intent.putExtra("title", item.title)
            intent.putExtra("desc", item.description)
            startActivity(intent)
        }


        tasksList2 = mutableListOf()
        taskAdapter2 =Adapter_NotCompleted_Guest(tasksList2)
        taskRecyclerView2.apply {
            layoutManager = LinearLayoutManager(this@Guest, LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter2
        }

        val secondActbutton = findViewById<FloatingActionButton>(R.id.cam2)
        secondActbutton.setOnClickListener{

            val intent = Intent(this,AddTask_guest::class.java).apply {
                putExtra("name", name)
            }
            startActivity(intent)

        }

        val thirdActbutton = findViewById<ImageView>(R.id.profile)
        thirdActbutton.setOnClickListener{

            val intent = Intent(this,Profile_guest::class.java).apply {
                putExtra("name", name)
            }
            startActivity(intent)

        }

        fetchData(name.toString())
        fetchData2(name.toString())

    }


    private fun fetchData(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_not.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_Completed(name, decription , hour,minute,type, email, country, phno)
                            tasksList.add(user)
                        }
                        taskAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }




    private fun fetchData2(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_completed.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_NotCompleted(name, decription , hour,minute,type, email, country, phno)
                            tasksList2.add(user)
                        }
                        taskAdapter2.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }



}