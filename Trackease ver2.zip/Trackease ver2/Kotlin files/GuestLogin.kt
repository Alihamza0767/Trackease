package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

class GuestLogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guest_login)

        val editText1 = findViewById<EditText>(R.id.editText)

        val seventhActbutton = findViewById<Button>(R.id.b1)
        seventhActbutton.setOnClickListener{

            val text1 = editText1.text.toString()

            val intent = Intent(this, Guest::class.java).apply {
                putExtra("name", text1)
            }
            startActivity(intent)
        }
    }
}