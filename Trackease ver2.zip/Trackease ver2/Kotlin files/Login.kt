package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.mohammadhaadi.smd_project.databinding.ActivityLogin2Binding


class Login : AppCompatActivity() {

    private lateinit var databaseReference: DatabaseReference
    private lateinit var databaseReference2: DatabaseReference
    private lateinit var binding: ActivityLogin2Binding

    private lateinit var firebaseAuth: FirebaseAuth
    private var name: String? = null
    private var utype: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogin2Binding.inflate(layoutInflater)
        setContentView(binding.root)


        firebaseAuth = FirebaseAuth.getInstance()

        val button = findViewById<TextView>(R.id.t9)
        button.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        }
        val button2 = findViewById<ImageView>(R.id.previous)
        button2.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, start4::class.java)
            startActivity(intent)
        }
        val button3 = findViewById<TextView>(R.id.t7)
        button3.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, GuestLogin::class.java)
            startActivity(intent)
        }


        //auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("User")
        databaseReference2 = FirebaseDatabase.getInstance().getReference("Admin")


        binding.b1.setOnClickListener {
            val email = binding.editText.text.toString()
            val pass = binding.editText2.text.toString()


            if (email.isNotEmpty() && pass.isNotEmpty()){
                firebaseAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener{ task ->

                    if(task.isSuccessful){

                        databaseReference.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object :
                            ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                for (ds in dataSnapshot.children) {
                                    utype = ds.child("usertype").value.toString()
                                    //nameTextView.text = username
                                    name = utype
                                    //Toast.makeText(this@Login,name, Toast.LENGTH_SHORT).show()

                                }

                                if(name == "Admin"){
                                    // Toast.makeText(this@Login,"Working", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this@Login,Admin::class.java)
                                    intent.putExtra("email", email)
                                    startActivity(intent)
                                }else{
                                    val intent = Intent(this@Login,NavBar_Backscreen::class.java)
                                    intent.putExtra("email", email)
                                    startActivity(intent)
                                }


                            }

                            override fun onCancelled(databaseError: DatabaseError) {
                                // Handle error for the first query
                            }

                        })

                        databaseReference2.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                for (ds in dataSnapshot.children) {
                                    utype = ds.child("usertype").value.toString()
                                    name =  utype

                                }

                                if(name == "Admin"){
                                    // Toast.makeText(this@Login,"Working", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this@Login,Admin::class.java)
                                    intent.putExtra("email", email)
                                    startActivity(intent)
                                }else{
                                    val intent = Intent(this@Login,NavBar_Backscreen::class.java)
                                    intent.putExtra("email", email)
                                    startActivity(intent)
                                }

                            }

                            override fun onCancelled(databaseError: DatabaseError) {
                                // Handle error for the second query
                            }
                        })

                        //Toast.makeText(this@Login,name, Toast.LENGTH_SHORT).show()




                    }else{
                        Toast.makeText(
                            this,
                            "Sign-in failed: ${task.exception?.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }else{
                Toast.makeText(this,"Empty fields are not allowed", Toast.LENGTH_SHORT).show()
            }
        }

     //   val button1 = findViewById<TextView>(R.id.t7)
    //    button1.setOnClickListener {
            // Create an Intent to start the new activity
     //       val intent = Intent(this, GuestLogin::class.java)
    //        startActivity(intent)
     //   }

    }

}
