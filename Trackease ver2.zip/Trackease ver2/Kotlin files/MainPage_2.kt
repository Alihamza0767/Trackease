package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.mohammadhaadi.smd_project.fragments.CalenderFragment
import com.mohammadhaadi.smd_project.fragments.FocusFragment
import com.mohammadhaadi.smd_project.fragments.IndexFragment
import com.mohammadhaadi.smd_project.fragments.ProfileFragment
import androidx.fragment.app.Fragment

class MainPage_2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_page2)





        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val items = listOf(
            Task_NotCompleted("English Homework", "Today at 08:37","Work","2"),
            Task_NotCompleted("Maths Homework", "Tom at 08:37","Work","1")
        )

        val adapter = TaskAdapter_NotCompleted(items)
        recyclerView.adapter = adapter




        val recyclerView2: RecyclerView = findViewById(R.id.recyclerView2)
        recyclerView2.layoutManager = LinearLayoutManager(this)

        val items2 = listOf(
            Task_Completed("Physics Homework", "Today at 08:37","Work","3")
        )

        val adapter2 = TaskAdapter_Completed(items2)
        recyclerView2.adapter = adapter2

    }




}