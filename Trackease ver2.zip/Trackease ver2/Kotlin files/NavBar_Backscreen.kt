package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.mohammadhaadi.smd_project.fragments.CalenderFragment
import com.mohammadhaadi.smd_project.fragments.FocusFragment
import com.mohammadhaadi.smd_project.fragments.IndexFragment
import com.mohammadhaadi.smd_project.fragments.ProfileFragment

class NavBar_Backscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nav_bar_backscreen)


        val completed = intent.getStringExtra("completed")
        val notcompleted = intent.getStringExtra("notcompleted")
        val email = intent.getStringExtra("email")
        val name = intent.getStringExtra("name")







        val indexFragment = IndexFragment()
        val focusFragment = FocusFragment()
        val calenderFragment = CalenderFragment()
        val profileFragment = ProfileFragment()


        val bundle = Bundle().apply {
            putString("completed", completed)
            putString("notcompleted", notcompleted)
            putString("email", email)
            putString("name", email)
        }





        indexFragment.arguments = bundle
        makeCurrentFragment(indexFragment)

        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.ic_home -> makeCurrentFragment(indexFragment)
                R.id.ic_search -> makeCurrentFragment(calenderFragment)
                R.id.ic_chat -> {

                    focusFragment.arguments = bundle
                    makeCurrentFragment(focusFragment)
                }
                R.id.ic_profile -> {

                    profileFragment.arguments = bundle
                    makeCurrentFragment(profileFragment)

                }
            }
            true
        }




        val seventhActbutton = findViewById<FloatingActionButton>(R.id.cam)
        seventhActbutton.setOnClickListener{
            val intent = Intent(this, AddTask::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }




    }


    private fun makeCurrentFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }


}