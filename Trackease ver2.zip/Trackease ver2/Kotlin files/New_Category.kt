package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class New_Category : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_category)

        val editText1 = findViewById<EditText>(R.id.editText)
        val editText2 = findViewById<EditText>(R.id.editText2)

        val fourthActbutton = findViewById<Button>(R.id.b1)
        fourthActbutton.setOnClickListener{

            val text1 = editText1.text.toString()
            val text2 = editText2.text.toString()

            sendDataToServer2(text1,text2,"sami@gmail.com")

        }



    }


    private fun sendDataToServer2(category: String, description: String,email: String) {
        val url = "http://192.168.32.1/SMD_Project/insert_category.php"
        val requestQueue = Volley.newRequestQueue(this@New_Category)

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                Toast.makeText(this@New_Category, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("response", it.toString())
                // If you expect a JSON object in the response, handle it here
                try {
                    val res = JSONObject(it)
                    val success = res.getInt("status")
                    val message = res.getString("message")
                    Toast.makeText(this@New_Category, message, Toast.LENGTH_SHORT).show()
                    if (success == 1) {
                        // Data inserted successfully
                        // Handle your logic here
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(this@New_Category, it.toString(), Toast.LENGTH_LONG).show()
                Log.e("error", it.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["category"] = category
                params["description"] = description
                params["email"] = email

                return params
            }
        }
        requestQueue.add(stringRequest)
    }

}





