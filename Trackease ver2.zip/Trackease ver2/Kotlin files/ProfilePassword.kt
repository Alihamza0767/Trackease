package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ProfilePassword : AppCompatActivity() {

    private lateinit var databaseReference: DatabaseReference
    private lateinit var databaseReference2: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var pass: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_password)

        val email = intent.getStringExtra("email")
        val oldPassEditText = findViewById<EditText>(R.id.et1)
        val newPassEditText = findViewById<EditText>(R.id.et2)
        val editButton = findViewById<Button>(R.id.edit1)

        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("User")
        databaseReference2 = FirebaseDatabase.getInstance().getReference("Admin")


        // Set OnClickListener on the edit button
        editButton.setOnClickListener {
            val oldPass = oldPassEditText.text.toString()
            val newPass = newPassEditText.text.toString()

            if (oldPass.isEmpty() || newPass.isEmpty()) {
                Toast.makeText(applicationContext, "Please enter both old and new passwords", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            databaseReference.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object :
                ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        val user = dataSnapshot.children.first() // Get the first user with the specified email
                        val userId = user.key // Get the user ID
                        val storedPass = user.child("pass").value.toString()

                        if (oldPass == storedPass) {
                            // Update the password in the database
                            // Update the password in the database
                            userId?.let {
                                databaseReference.child(it).child("pass").setValue(newPass)
                                    .addOnSuccessListener {
                                        // Update the password in Firebase Authentication
                                        val user = FirebaseAuth.getInstance().currentUser
                                        user?.updatePassword(newPass)
                                            ?.addOnCompleteListener { task ->
                                                if (task.isSuccessful) {
                                                    // Password updated successfully
                                                    Toast.makeText(applicationContext, "Password updated successfully", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    // Failed to update password
                                                    Toast.makeText(applicationContext, "Failed to update password: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }

                                        // Navigate back to the Profile activity
                                        val intent = Intent(this@ProfilePassword, NavBar_Backscreen::class.java)
                                        intent.putExtra("email", email)
                                        startActivity(intent)
                                        finish() // Finish the current activity
                                    }
                                    .addOnFailureListener { e ->
                                        Toast.makeText(applicationContext, "Failed to update password: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }

                            }

                        } else {
                            Toast.makeText(applicationContext, "Old password does not match", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        // If not found in the User node, check the Admin node
                        databaseReference2.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object :
                            ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    val user = dataSnapshot.children.first() // Get the first user with the specified email
                                    val userId = user.key // Get the user ID
                                    val storedPass = user.child("pass").value.toString()

                                    if (oldPass == storedPass) {
                                        // Update the password in the database
                                        // Update the password in the database
                                        userId?.let {
                                            databaseReference2.child(it).child("pass").setValue(newPass)
                                                .addOnSuccessListener {
                                                    // Update the password in Firebase Authentication
                                                    val user = FirebaseAuth.getInstance().currentUser
                                                    user?.updatePassword(newPass)
                                                        ?.addOnCompleteListener { task ->
                                                            if (task.isSuccessful) {
                                                                // Password updated successfully
                                                                Toast.makeText(applicationContext, "Password updated successfully", Toast.LENGTH_SHORT).show()
                                                            } else {
                                                                // Failed to update password
                                                                Toast.makeText(applicationContext, "Failed to update password: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }

                                                    // Navigate back to the Profile activity
                                                    val intent = Intent(this@ProfilePassword, NavBar_Backscreen::class.java)
                                                    intent.putExtra("email", email)
                                                    startActivity(intent)
                                                    finish() // Finish the current activity
                                                }
                                                .addOnFailureListener { e ->
                                                    Toast.makeText(applicationContext, "Failed to update password: ${e.message}", Toast.LENGTH_SHORT).show()
                                                }
                                        }

                                    } else {
                                        Toast.makeText(applicationContext, "Old password does not match", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(applicationContext, "User not found", Toast.LENGTH_SHORT).show()
                                }
                            }

                            override fun onCancelled(databaseError: DatabaseError) {
                                // Handle error for the Admin node query
                            }
                        })
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle error for the User node query
                }
            })
        }

    }
}