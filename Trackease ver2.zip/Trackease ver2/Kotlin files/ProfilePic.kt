package com.mohammadhaadi.smd_project

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.mohammadhaadi.smd_project.databinding.ActivityProfilePicBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProfilePic : AppCompatActivity() {

    private lateinit var binding: ActivityProfilePicBinding
    private lateinit var ImageUri: Uri


    private var name: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilePicBinding.inflate(layoutInflater)
        setContentView(binding.root)

        name = intent.getStringExtra("name")

        binding.button2.setOnClickListener {

            selectImage()
        }

        binding.button3.setOnClickListener {

            uploadImage()
        }
    }

    private fun uploadImage() {
        val progressDialog = AlertDialog.Builder(this)
            .setMessage("Uploading File...")
            .setCancelable(false)
            .show()

        val formatter = SimpleDateFormat("yyyy_MM_dd_HH_mmm_ss", Locale.getDefault())
        val now = Date()
        val filename = formatter.format(now)

        // Receive name from previous page through intent
        val name = intent.getStringExtra("name")

        // Show the name in a Toast message
        Toast.makeText(this@ProfilePic, "Received name: $name", Toast.LENGTH_SHORT).show()

        // Set the image name to the received name
        val imageName = "$name.jpeg" // Assuming the image format is JPG

        val storageReference: StorageReference = FirebaseStorage.getInstance().reference.child("Images/$imageName")

        storageReference.putFile(ImageUri)
            .addOnSuccessListener {
                binding.imageView.setImageURI(null)
                Toast.makeText(this@ProfilePic, "Successfully uploaded", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@ProfilePic, NavBar_Backscreen::class.java)
                // Start the next activity
                intent.putExtra("email",name)
                startActivity(intent)
                progressDialog.dismiss()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this@ProfilePic, "Failed to upload image", Toast.LENGTH_SHORT).show()
                progressDialog.dismiss()
            }
    }


    private fun selectImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT

        startActivityForResult(intent,100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 100 && resultCode == RESULT_OK){
            ImageUri = data?.data!!
            binding.imageView.setImageURI(ImageUri)
        }

    }
}