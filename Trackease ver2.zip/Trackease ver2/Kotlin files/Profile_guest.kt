package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Profile_guest : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_guest)

        val name = intent.getStringExtra("name")


        val textView = findViewById<TextView>(R.id.name)
        textView.text = name


    }
}