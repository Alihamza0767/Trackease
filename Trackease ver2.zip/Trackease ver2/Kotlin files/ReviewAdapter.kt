package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ReviewAdapter(private val reviewslist: MutableList<Reviews>) :
    RecyclerView.Adapter<ReviewAdapter.MyViewHolder>() {

    class MyViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        var textView: TextView = view.findViewById(R.id.name)
        var textView2: TextView = view.findViewById(R.id.review)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.activity_review_items_row, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val currentUser = reviewslist[position]
        holder.textView.text = currentUser.email
        holder.textView2.text = currentUser.reviewText


    }

    override fun getItemCount(): Int {
        return reviewslist.size
    }
}