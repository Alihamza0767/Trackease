package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class Review_User_Guest : AppCompatActivity() {

    private lateinit var reviewRecyclerView: RecyclerView
    private lateinit var reviewsList: MutableList<Reviews>
    private lateinit var reviewAdapter: ReviewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_user_guest)

        reviewRecyclerView = findViewById(R.id.reviewrecycler)

        reviewsList = mutableListOf()
        reviewAdapter = ReviewAdapter(reviewsList)
        reviewRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@Review_User_Guest, LinearLayoutManager.VERTICAL, false)
            adapter = reviewAdapter

        }

        fetchData()
    }




    private fun fetchData() {
        val url = "http://192.168.32.1/SMD_Project/retrieve_admin.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val email = obj.getString("email")
                            val review = obj.getString("review")
                            val user = Reviews(email, review)
                            reviewsList.add(user)
                        }
                        reviewAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                return HashMap()
            }
        }
        Volley.newRequestQueue(this).add(stringRequest)
    }




}