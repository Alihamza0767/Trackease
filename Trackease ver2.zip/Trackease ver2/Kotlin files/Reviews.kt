package com.mohammadhaadi.smd_project

data class Reviews(

    var email: String = "",
    var reviewText: String = ""


)
