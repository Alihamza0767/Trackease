package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SearchResults : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_results)

        val title = intent.getStringExtra("searchQuery")
        val day = intent.getStringExtra("day")
        val category = intent.getStringExtra("category")
        val priority = intent.getStringExtra("priority")

        val cityTextView = findViewById<TextView>(R.id.title)
        cityTextView.text = title


        val cityTextView2 = findViewById<TextView>(R.id.time)
        cityTextView2.text = day


        val cityTextView3 = findViewById<TextView>(R.id.category)
        cityTextView3.text = category


        val cityTextView4 = findViewById<TextView>(R.id.priority)
        cityTextView4.text = priority

    }
}