package com.mohammadhaadi.smd_project


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/*class TaskAdapter_Completed(private val items: List<Task_Completed>) :
    RecyclerView.Adapter<TaskAdapter_Completed.ItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_task_completed_row, parent, false)
        return ItemViewHolder(view)
    }


    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int {
        return items.size
    }

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewItem: TextView = itemView.findViewById(R.id.title)
        private val textViewDescription: TextView = itemView.findViewById(R.id.time)
        private val textViewDescription2: TextView = itemView.findViewById(R.id.category)
        private val textViewDescription3: TextView = itemView.findViewById(R.id.priority)

        fun bind(item: Task_Completed) {
            textViewItem.text = item.title
            textViewDescription.text = item.day
            textViewDescription2.text = item.category
            textViewDescription3.text = item.priority
        }
    }
}*/


class TaskAdapter_Completed(private val items: List<Task_Completed>) :
    RecyclerView.Adapter<TaskAdapter_Completed.ItemViewHolder>() {

    // Define a listener interface
    interface OnItemClickListener {
        fun onItemClick(item: Task_Completed)
    }

    private var listener: OnItemClickListener? = null

    fun setOnItemClickListener(listener: (Task_Completed) -> Unit) {
        this.listener = object : OnItemClickListener {
            override fun onItemClick(item: Task_Completed) {
                listener(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_task_completed_row, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewItem: TextView = itemView.findViewById(R.id.title)
        private val textViewDescription: TextView = itemView.findViewById(R.id.time)
        private val textViewDescription2: TextView = itemView.findViewById(R.id.category)
        private val textViewDescription3: TextView = itemView.findViewById(R.id.priority)

        init {
            // Set click listener to the title TextView
            textViewItem.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener?.onItemClick(items[position])
                }
            }
        }

        fun bind(item: Task_Completed) {
            textViewItem.text = item.title
            textViewDescription.text = item.day
            textViewDescription2.text = item.category
            textViewDescription3.text = item.priority
        }
    }
}


