package com.mohammadhaadi.smd_project

data class Tasks(

    var title: String = "",
    var description: String = "",
    var hour: String = "",
    var minute: String = "",
    var type: String = "",
    var day: String = "",
    var priority: String = "",
    var category: String = ""


)
