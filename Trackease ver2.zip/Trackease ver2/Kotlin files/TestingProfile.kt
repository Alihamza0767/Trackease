package com.mohammadhaadi.smd_project

import android.app.ProgressDialog
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.mohammadhaadi.smd_project.databinding.ActivityTestingProfileBinding
import java.io.File

class TestingProfile : AppCompatActivity() {

    private lateinit var databaseReference: DatabaseReference
    private lateinit var databaseReference2: DatabaseReference
    private lateinit var binding: ActivityTestingProfileBinding

    private lateinit var auth: FirebaseAuth
    private var name: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTestingProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val email = intent.getStringExtra("email")
        var name = intent.getStringExtra("namee")


        val nameTextView = findViewById<TextView>(R.id.name)
        nameTextView.text = name

        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference("User")
        databaseReference2 = FirebaseDatabase.getInstance().getReference("Admin")

        databaseReference.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (ds in dataSnapshot.children) {
                    val username = ds.child("username").value.toString()
                    nameTextView.text = username
                    name = username
                }
                retrieveImageFromDatabase(name)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error for the first query
            }
        })

        databaseReference2.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (ds in dataSnapshot.children) {
                    val username = ds.child("username").value.toString()
                    nameTextView.text = username
                    name =  username
                }
                retrieveImageFromDatabase(name)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error for the second query
            }
        })


   //     val imageView: ImageView = findViewById(R.id.img1)
   //     val imageView2: ImageView = findViewById(R.id.img2)
    //    val imageView3: ImageView = findViewById(R.id.img3)

        // Set an OnClickListener on the ImageView
 //       imageView.setOnClickListener {
            // Define the Intent to navigate to the next activity
  //          val intent = Intent(this@TestingProfile, ProfileName::class.java)
            // Start the next activity
  //          intent.putExtra("email",email)
  //          startActivity(intent)
  //      }

  //      imageView2.setOnClickListener {
            // Define the Intent to navigate to the next activity
  //          val intent = Intent(this@P, ProfilePassowrd::class.java)
            // Start the next activity
 //           intent.putExtra("email",email)
   //         startActivity(intent)
  //      }

  //      imageView3.setOnClickListener {
            // Define the Intent to navigate to the next activity
  //          val intent = Intent(this@Profile, Profilepic::class.java)
            // Start the next activity
  //          intent.putExtra("name",name)
   //         startActivity(intent)
  //      }


    }

    private fun retrieveImageFromDatabase(uname: String?) {
        uname?.let { username ->
            val progressDialog = ProgressDialog(this@TestingProfile)
            progressDialog.setMessage("Fetching image...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            val storageRef = FirebaseStorage.getInstance().reference.child("Images/$username.jpeg")
            val localFile = File.createTempFile("tempImage", "jpeg")

            storageRef.getFile(localFile)
                .addOnSuccessListener {
                    // File download success
                    val bitmap = BitmapFactory.decodeFile(localFile.absolutePath)
                    binding.pic.setImageBitmap(bitmap)
                    progressDialog.dismiss()
                }
                .addOnFailureListener { exception ->
                    // File download failed
                    progressDialog.dismiss()
                    Log.e("FirebaseStorage", "Error downloading image: ${exception.message}", exception)
                    Toast.makeText(this@TestingProfile, "Failed to download image", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Log.e("FirebaseStorage", "Username is null")
            Toast.makeText(this@TestingProfile, "Username is null", Toast.LENGTH_SHORT).show()
        }
    }

}
