package com.mohammadhaadi.smd_project.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.mohammadhaadi.smd_project.AddTask_Date
import com.mohammadhaadi.smd_project.CalenderView2_Completed
import com.mohammadhaadi.smd_project.EditTask
import com.mohammadhaadi.smd_project.R
import com.mohammadhaadi.smd_project.TaskAdapter_Completed
import com.mohammadhaadi.smd_project.TaskAdapter_NotCompleted
import com.mohammadhaadi.smd_project.Task_Completed
import com.mohammadhaadi.smd_project.Task_NotCompleted
import org.json.JSONException
import org.json.JSONObject

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private lateinit var comp: TextView

/**
 * A simple [Fragment] subclass.
 * Use the [CalenderFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CalenderFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var taskRecyclerView: RecyclerView
    private lateinit var tasksList: MutableList<Task_NotCompleted>
    private lateinit var taskAdapter: TaskAdapter_NotCompleted
    private lateinit var selectedDate: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)






        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_calender, container, false)
        taskRecyclerView = view.findViewById(R.id.recyclerView)
        return view
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        comp = view.findViewById(R.id.comp)

        // Set click listener to the TextView
        comp.setOnClickListener {

            val intent = Intent(requireContext(), CalenderView2_Completed::class.java)
            startActivity(intent)
        }

        tasksList = mutableListOf()
        taskAdapter = TaskAdapter_NotCompleted(tasksList)
        taskRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter
        }

        taskAdapter.setOnItemClickListener { item: Task_NotCompleted ->

            val intent = Intent(requireContext(), EditTask::class.java)
            intent.putExtra("title", item.title)
            intent.putExtra("desc", item.description)
            intent.putExtra("hour", item.hour)
            intent.putExtra("minute", item.minute)
            intent.putExtra("type", item.type)
            intent.putExtra("category", item.category)
            intent.putExtra("priority", item.priority)
            startActivity(intent)
        }

        val calendarView = view.findViewById<CalendarView>(R.id.calenderView)

        calendarView.setOnDateChangeListener { view, year, month, dayOfMonth ->
            // Month is 0 based, so add 1 to month
            val formattedMonth = if (month < 9) "0${month + 1}" else "${month + 1}"
            val formattedDayOfMonth = if (dayOfMonth < 10) "0$dayOfMonth" else "$dayOfMonth"

            selectedDate = "$formattedDayOfMonth"
            Toast.makeText(activity, selectedDate, Toast.LENGTH_SHORT).show()

            fetchData_Date(selectedDate)

        }

    }








    private fun fetchData_Date(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_date.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_NotCompleted(name, decription , hour,minute,type, email, country, phno)
                            tasksList.add(user)
                        }
                        taskAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["day"] = email
                return params
            }
        }
        Volley.newRequestQueue(requireContext()).add(stringRequest)
    }








    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CalenderFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CalenderFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }










}