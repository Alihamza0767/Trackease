package com.mohammadhaadi.smd_project.fragments

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.mohammadhaadi.smd_project.Category
import com.mohammadhaadi.smd_project.Focus
import com.mohammadhaadi.smd_project.ProfileName
import com.mohammadhaadi.smd_project.ProfilePassword
import com.mohammadhaadi.smd_project.ProfilePic
import com.mohammadhaadi.smd_project.R
import org.json.JSONException
import org.json.JSONObject

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FocusFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class FocusFragment : Fragment() {

    private var param1: String? = null
    private var param2: String? = null
    private var email: String? = null
    private lateinit var timer: TextView
    private lateinit var insta: TextView
    private lateinit var facebook: TextView
    private var secondsPassed = 0
    private val handler = Handler(Looper.getMainLooper())
    private var isTimerRunning = false
    private lateinit var focusList: MutableList<Focus>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_focus, container, false)


        insta = view.findViewById(R.id.insta)
        facebook = view.findViewById(R.id.facebook)


        insta.setOnClickListener {


            val instagramProfile = "https://www.instagram.com/syedmuhammadsaadsalman/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(instagramProfile))
            intent.setPackage("com.instagram.android") // Ensures that the intent is only handled by the Instagram app
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                // Instagram app is not installed, open in browser instead
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(instagramProfile)))
            }

        }




        facebook.setOnClickListener {


            val instagramProfile = "https://www.facebook.com/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(instagramProfile))
            intent.setPackage("com.facebook.android") // Ensures that the intent is only handled by the Instagram app
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                // Instagram app is not installed, open in browser instead
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(instagramProfile)))
            }

        }



        val barChart = BarChart(requireContext())
        barChart.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        val rootView = view.findViewById<ViewGroup>(R.id.container)
        rootView.addView(barChart)

        focusList = mutableListOf()

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        email = arguments?.getString("email")

        fetchData(email.toString())

        val start = view.findViewById<Button>(R.id.starter)

        timer = view.findViewById(R.id.timer)

       start.setOnClickListener {
            if (isTimerRunning) {
                stopTimer()
            } else {
                startTimer()
            }

            isTimerRunning = !isTimerRunning

        }

    }

    private fun startTimer() {
        handler.post(object : Runnable {
            override fun run() {
                secondsPassed++
                timer.text = "Timer: $secondsPassed"
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun stopTimer() {
        handler.removeCallbacksAndMessages(null)
        val storedTimerValue = secondsPassed
        secondsPassed = 0
        timer.text = "Timer: 0"
        Log.d("FocusFragment", "Final timer value: $storedTimerValue")
        sendDataToServer2(storedTimerValue.toString(), email.toString())
    }

    private fun sendDataToServer2(time: String,email: String) {
        val url = "http://192.168.32.1/SMD_Project/insert_focus.php"
        val requestQueue = Volley.newRequestQueue(requireContext())

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_LONG).show()
                Log.e("response", it.toString())
                try {
                    val res = JSONObject(it)
                    val success = res.getInt("status")
                    val message = res.getString("message")
                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    if (success == 1) {
                        // Data inserted successfully
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_LONG).show()
                Log.e("error", it.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["time"] = time
                params["email"] = email
                return params
            }
        }
        requestQueue.add(stringRequest)
    }

    private fun fetchData(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_focus.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val id = obj.getString("id")
                            val time = obj.getString("time")
                            val user = Focus(id.toString(), time.toString())

                            focusList.add(user)
                        }
                        populateBarChart()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(requireContext(), error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(requireContext()).add(stringRequest)
    }

    private fun populateBarChart() {
        val barChart = requireView().findViewById<BarChart>(R.id.barChart)

        val entries = ArrayList<BarEntry>()
        for (focus in focusList) {
            Toast.makeText(requireContext(), focus.id , Toast.LENGTH_SHORT).show()
            entries.add(BarEntry(focus.id.toFloat(), focus.time.toFloat()))
        }

        val dataSet = BarDataSet(entries, "Stats")
        dataSet.barBorderWidth = 0.1f

        dataSet.setColors(Color.parseColor("#8875FF"))

        val data = BarData(dataSet)
        barChart.data = data
        barChart.xAxis.setDrawLabels(false)
        barChart.xAxis.setDrawGridLines(false)
        barChart.axisLeft.setDrawLabels(false)
        barChart.axisLeft.setDrawGridLines(false)
        barChart.invalidate()
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FocusFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}