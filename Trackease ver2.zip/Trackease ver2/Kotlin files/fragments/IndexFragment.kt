package com.mohammadhaadi.smd_project.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.mohammadhaadi.smd_project.DataBaseHandler
import com.mohammadhaadi.smd_project.DataBaseHandler2
import com.mohammadhaadi.smd_project.EditTask
import com.mohammadhaadi.smd_project.NavBar_Backscreen
import com.mohammadhaadi.smd_project.R
import com.mohammadhaadi.smd_project.SearchResults
import com.mohammadhaadi.smd_project.TaskAdapter_Completed
import com.mohammadhaadi.smd_project.TaskAdapter_NotCompleted
import com.mohammadhaadi.smd_project.Task_Completed
import com.mohammadhaadi.smd_project.Task_NotCompleted
import org.json.JSONException
import org.json.JSONObject

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private var editTextValue: String? = null

/**
 * A simple [Fragment] subclass.
 * Use the [IndexFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class IndexFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var taskRecyclerView: RecyclerView
    private lateinit var tasksList: MutableList<Task_Completed>
    private lateinit var taskAdapter: TaskAdapter_Completed
    private lateinit var taskRecyclerView2: RecyclerView
    private lateinit var tasksList2: MutableList<Task_NotCompleted>
    private lateinit var taskAdapter2: TaskAdapter_NotCompleted
    private var completedCount: Int? = 0
    private var nonCompletedCount: Int? = 0
    private var email: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_index, container, false)
        taskRecyclerView = view.findViewById(R.id.recyclerView)
        taskRecyclerView2 = view.findViewById(R.id.recyclerView2)


        val imageView = view.findViewById<ImageView>(R.id.pic)


        imageView.setOnClickListener {

            completedCount = taskAdapter.itemCount
            nonCompletedCount = taskAdapter2.itemCount

            val intent = Intent(requireContext(), NavBar_Backscreen::class.java)
            intent.putExtra("email",email)
            intent.putExtra("completed",completedCount.toString())
            intent.putExtra("notcompleted",nonCompletedCount.toString())
            startActivity(intent)

        }


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

       // val dbHelper = context?.let { DataBaseHandler(it) }
       // var dataList = dbHelper?.readData()                           //SQLlite

         //val dbHelper2 = context?.let { DataBaseHandler2(it) }
        //var dataList2 = dbHelper2?.readData()                           //SQLlite


        email = arguments?.getString("email")
        Toast.makeText(activity, email, Toast.LENGTH_SHORT).show()


        val editText = view.findViewById<EditText>(R.id.search)


        view.findViewById<Button>(R.id.enter).setOnClickListener {
            // Get the text from the EditText
            editTextValue = editText.text.toString()

            val n = editTextValue.toString()

            fetchData_specific(n)

        }

        tasksList = mutableListOf()
        taskAdapter = TaskAdapter_Completed(tasksList)
        taskRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter
        }

        tasksList2 = mutableListOf()
        taskAdapter2 = TaskAdapter_NotCompleted(tasksList2)
        taskRecyclerView2.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            adapter = taskAdapter2
        }


        taskAdapter.setOnItemClickListener { item: Task_Completed ->
            val intent = Intent(requireContext(), EditTask::class.java)
            intent.putExtra("title", item.title)
            intent.putExtra("desc", item.description)
            intent.putExtra("hour", item.hour)
            intent.putExtra("minute", item.minute)
            intent.putExtra("type", item.type)
            intent.putExtra("category", item.category)
            intent.putExtra("priority", item.priority)
            startActivity(intent)
        }


        taskAdapter2.setOnItemClickListener { item: Task_NotCompleted ->

            val intent = Intent(requireContext(), EditTask::class.java)

            intent.putExtra("title", item.title)
            intent.putExtra("desc", item.description)
            intent.putExtra("hour", item.hour)
            intent.putExtra("minute", item.minute)
            intent.putExtra("type", item.type)
            intent.putExtra("category", item.category)
            intent.putExtra("priority", item.priority)
            startActivity(intent)
        }



        fetchData(email.toString())
        fetchData2(email.toString())




    }


    private fun fetchData_specific(name: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_specifictask.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val retrievedName = obj.getString("title")
                            if (retrievedName.equals(name, ignoreCase = true)) {
                                val title = obj.getString("title")
                                val time = obj.getString("day")
                                val category = obj.getString("category")
                                val priority = obj.getString("priority")
                                val intent = Intent(activity, SearchResults::class.java).apply {
                                    putExtra("searchQuery", name)
                                    putExtra("day", time)
                                    putExtra("category", category)
                                    putExtra("priority", priority)
                                }
                                startActivity(intent)
                                return@Listener
                            }
                        }
                        Toast.makeText(activity, "No such user exists", Toast.LENGTH_SHORT).show()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {

            // Here we are adding the parameters to the request
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["title"] = name
                return params
            }
        }
        Volley.newRequestQueue(activity).add(stringRequest)
    }





    private fun fetchData(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_not.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_Completed(name, decription , hour,minute,type, email, country, phno)
                            tasksList.add(user)
                        }
                        taskAdapter.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(activity).add(stringRequest)
    }




    private fun fetchData2(email: String) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_task_completed.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val name = obj.getString("title")
                            val decription = obj.getString("description")
                            val hour = obj.getString("hour")
                            val minute = obj.getString("minute")
                            val type = obj.getString("type")
                            val email = obj.getString("day")
                            val phno = obj.getString("category")
                            val country = obj.getString("priority")
                            val user = Task_NotCompleted(name, decription , hour,minute,type, email, country, phno)
                            tasksList2.add(user)
                        }
                        taskAdapter2.notifyDataSetChanged()
                    } else {
                        val message = jsonObject.getString("message")
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.toString(), Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                return params
            }
        }
        Volley.newRequestQueue(activity).add(stringRequest)
    }



    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment IndexFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            IndexFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}