/*package com.mohammadhaadi.smd_project.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import com.mohammadhaadi.smd_project.R



// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private const val ARG_c1 = "completed"
private const val ARG_c2 = "notcompleted"

/**
 * A simple [Fragment] subclass.
 * Use the [ProfileFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ProfileFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view =  inflater.inflate(R.layout.fragment_profile, container, false)

        return view
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val completed = arguments?.getString(ARG_c1)
        val notCompleted = arguments?.getString(ARG_c2)


        var editText = view.findViewById<TextView>(R.id.completed)
        var editText2 = view.findViewById<TextView>(R.id.notcompleted)

        editText.text = completed
        editText2.text = notCompleted

    }





    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ProfileFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ProfileFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}*/



package com.mohammadhaadi.smd_project.fragments

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.mohammadhaadi.smd_project.ProfileName
import com.mohammadhaadi.smd_project.ProfilePassword
import com.mohammadhaadi.smd_project.ProfilePic
import com.mohammadhaadi.smd_project.R
import com.mohammadhaadi.smd_project.Review_User
import com.mohammadhaadi.smd_project.databinding.FragmentProfileBinding
import com.squareup.picasso.Picasso
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

private const val ARG_c1 = "completed"
private const val ARG_c2 = "notcompleted"

class ProfileFragment : Fragment() {

    private lateinit var databaseReference: DatabaseReference
    private lateinit var databaseReference2: DatabaseReference
    private lateinit var binding: FragmentProfileBinding
    private lateinit var auth: FirebaseAuth
    private var name: String? = null
    private lateinit var galleryLauncher: ActivityResultLauncher<Intent>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val completed = arguments?.getString(ARG_c1)
        val notCompleted = arguments?.getString(ARG_c2)
        val email = arguments?.getString("email")
         name = arguments?.getString("name")

        //Toast.makeText(requireContext(), email, Toast.LENGTH_SHORT).show()

        binding.completed.text = completed
        binding.notcompleted.text = notCompleted

        //val email = FirebaseAuth.getInstance().currentUser?.email

        if (email != null) {
            databaseReference = FirebaseDatabase.getInstance().getReference("User")
            databaseReference2 = FirebaseDatabase.getInstance().getReference("Admin")

            databaseReference.orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        for (ds in dataSnapshot.children) {
                            val username = ds.child("username").value.toString()
                            binding.name.text = username
                            name = username
                        }
                        retrieveImageFromDatabase(name)
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Handle error for the first query
                    }
                })

            databaseReference2.orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        for (ds in dataSnapshot.children) {
                            val username = ds.child("username").value.toString()
                            binding.name.text = username
                            name = username
                        }
                        retrieveImageFromDatabase(email)
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Handle error for the second query
                    }
                })
        }

        binding.img1.setOnClickListener {
            val intent = Intent(requireContext(), ProfileName::class.java)
            intent.putExtra("email", email)
            startActivity(intent)
        }

        binding.img2.setOnClickListener {
            // Define the Intent to navigate to the next activity
             val intent = Intent(requireContext(), ProfilePassword::class.java)
            // Start the next activity
             intent.putExtra("email", email)
             startActivity(intent)
        }

        binding.img3.setOnClickListener {
            // Define the Intent to navigate to the next activity
             val intent = Intent(requireContext(), ProfilePic::class.java)
            // Start the next activity
             intent.putExtra("name", email)
             startActivity(intent)
        }
        binding.rev.setOnClickListener {
            // Define the Intent to navigate to the next activity
            val intent = Intent(requireContext(), Review_User::class.java)
            // Start the next activity
            intent.putExtra("email", email)
            startActivity(intent)
        }


        galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                uri?.let {
                    uploadImageToServer(uri, email.toString(),view.findViewById(R.id.cover))
                }
            }
        }

        view.findViewById<ImageView>(R.id.cover).setOnClickListener {
            openGallery()
        }

        fetchData_Url(email.toString(),view.findViewById(R.id.cover))

    }

    private fun retrieveImageFromDatabase(uname: String?) {
        uname?.let { username ->
            val progressDialog = ProgressDialog(requireContext())
            progressDialog.setMessage("Fetching image...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            val storageRef = FirebaseStorage.getInstance().reference.child("Images/$username.jpeg")
            val localFile = File.createTempFile("tempImage", "jpeg")

            storageRef.getFile(localFile)
                .addOnSuccessListener {
                    // File download success
                    val bitmap = BitmapFactory.decodeFile(localFile.absolutePath)
                    binding.pic.setImageBitmap(bitmap)
                    progressDialog.dismiss()
                }
                .addOnFailureListener { exception ->
                    // File download failed
                    progressDialog.dismiss()
                    Log.e("FirebaseStorage", "Error downloading image: ${exception.message}", exception)
                    Toast.makeText(requireContext(), "Failed to download image", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Log.e("FirebaseStorage", "Username is null")
            Toast.makeText(requireContext(), "Username is null", Toast.LENGTH_SHORT).show()
        }
    }






    private fun uploadImageToServer(imageUri: Uri, email: String, imageView: ImageView) {
        val url = "http://192.168.32.1/SMD_Project/upload_image.php" // Replace this with your server URL

        val requestQueue = Volley.newRequestQueue(requireContext())
        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val imageUrl = jsonResponse.getString("url")

                    sendDataToServer(imageUrl,email)


                    // Handle the response accordingly
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                error.printStackTrace()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()

                // Convert image data to Base64
                val inputStream = requireContext().contentResolver.openInputStream(imageUri)
                val bytes = ByteArrayOutputStream()
                inputStream?.copyTo(bytes)
                val imageBytes = bytes.toByteArray()
                val imageBase64 = Base64.encodeToString(imageBytes, Base64.DEFAULT)

                params["image"] = imageBase64 // Pass the Base64 encoded image data to the server
                return params
            }
        }

        requestQueue.add(stringRequest)
    }






    private fun openGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        galleryLauncher.launch(intent)
    }



    private fun sendDataToServer(imageurl: String, email: String) {
        val url = "http://192.168.32.1/SMD_Project/insert_image.php"
        val requestQueue = Volley.newRequestQueue(requireContext()) // Use requireContext() instead of this

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_LONG).show()
                Log.e("response", it.toString())
                // If you expect a JSON object in the response, handle it here
                try {
                    val res = JSONObject(it)
                    val success = res.getInt("status")
                    val message = res.getString("message")
                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    if (success == 1) {
                        // Data inserted successfully
                        // Handle your logic here
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_LONG).show()
                Log.e("error", it.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["cover_url"] = imageurl
                params["profile_url"] = ""
                params["email"] = email
                return params
            }
        }
        requestQueue.add(stringRequest)
    }


    private fun fetchData_Url(email: String, imageView: ImageView) {
        val url = "http://192.168.32.1/SMD_Project/retrieve_cover_profilepics.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val success = jsonObject.getInt("status")
                    if (success == 1) {
                        val dataArray = jsonObject.getJSONArray("data")
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)
                            val cover_url = obj.getString("cover_url")
                            loadImageFromUrl(cover_url,imageView)
                            return@Listener
                        }
                    } else {
                        val message = jsonObject.getString("message")
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error ->
                error.printStackTrace()
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email // Pass the email parameter to the PHP script
                return params
            }
        }
        Volley.newRequestQueue(activity).add(stringRequest)
    }


    fun loadImageFromUrl(url: String, imageView: ImageView) {
        Picasso.get()
            .load(url)
            .into(imageView)
    }








}