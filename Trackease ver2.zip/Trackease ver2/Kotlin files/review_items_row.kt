package com.mohammadhaadi.smd_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class review_items_row : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_items_row)
    }
}