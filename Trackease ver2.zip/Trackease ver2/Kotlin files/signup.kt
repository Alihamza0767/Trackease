package com.mohammadhaadi.smd_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.mohammadhaadi.smd_project.databinding.ActivitySignupBinding

class signup : AppCompatActivity() {

    lateinit var binding: ActivitySignupBinding
    lateinit var firebaseAuth: FirebaseAuth
    lateinit var database: DatabaseReference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        // Sample dropdown items
        val items = listOf("Admin", "User", "Guest")

        // Initializing spinner
        val spinner: Spinner = findViewById(R.id.spinner)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        // Set OnClickListener to the button
        binding.b1.setOnClickListener {
            // Retrieve values from EditText fields
            val utype = spinner.selectedItem.toString()
            val uname = binding.editText.text.toString()
            val email = binding.editText2.text.toString()
            val pass = binding.editText21.text.toString()

            // Check if all fields are filled
            if (utype.isNotEmpty() && uname.isNotEmpty() && email.isNotEmpty() && pass.isNotEmpty()) {
                firebaseAuth.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            // User created successfully, navigate to Login page
                            val intent = Intent(this@signup, Login::class.java)
                            startActivity(intent)
                        } else {
                            // Display error message if user creation failed
                            Toast.makeText(
                                this@signup,
                                task.exception.toString(),
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        // Save user data based on type (Admin/User)
                        database = FirebaseDatabase.getInstance()
                            .getReference(if (utype == "Admin") "Admin" else "User")
                        val user = User(utype, uname, email, pass)
                        database.child(email.replace(".", ","))
                            .setValue(user) // Using email as child node
                            .addOnSuccessListener {
                                // Clear EditText fields after successful data save
                                binding.editText.text.clear()
                                binding.editText2.text.clear()
                                binding.editText21.text.clear()

                                Toast.makeText(
                                    this@signup,
                                    "Successfully saved",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }.addOnFailureListener {
                                // Display error message if data save failed
                                Toast.makeText(this@signup, "Failed", Toast.LENGTH_SHORT).show()
                            }
                    }
            } else {
                // Display a toast if any field is empty
                Toast.makeText(
                    this@signup,
                    "All fields are required",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Get EditText reference
        val editText: EditText = findViewById(R.id.editText111)

        // Set OnClickListener to the EditText
        editText.setOnClickListener {
            spinner.performClick() // Programmatically trigger the dropdown menu
        }

        val button = findViewById<TextView>(R.id.t7)
        button.setOnClickListener {
            // Create an Intent to start the new activity
            val intent = Intent(this, GuestLogin::class.java)
            startActivity(intent)
        }
    }
}